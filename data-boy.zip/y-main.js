const { app, BrowserWindow } = require('electron');
const path = require('path');

function createWindow() {
  const win = new BrowserWindow({
    width: 1000,
    height: 700,
    backgroundColor: "#000000",
    icon: path.join(__dirname, "icon.png"), // optional
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true
    }
  });

  win.loadFile("index.html");
}

app.whenReady().then(createWindow);
if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("/service-worker.js");
}


